#!/usr/bin/env python3
"""Export the prototype into one HTML file, with no network dependencies."""
from pathlib import Path
import re
import zipfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'dist'
OUT.mkdir(exist_ok=True)
html = (ROOT / 'index.html').read_text()
html = html.replace('<link rel="stylesheet" href="styles.css">', '<style>' + (ROOT / 'styles.css').read_text() + '</style>')
def embed_script(match):
    # Follow the HTML load order: adding a module never requires a second list.
    relative = match.group(1)
    path = (ROOT / relative).resolve()
    if not path.is_relative_to(ROOT) or not relative.startswith('src/'):
        raise ValueError(f'Unsupported script: {relative}')
    js = path.read_text().replace('</script', '<\\/script')
    return '<script>\n' + js + '\n</script>'

html = re.sub(r'<script src="([^"]+)"></script>', embed_script, html)
destination = OUT / 'nereide-prototype.html'
destination.write_text(html)
(OUT / 'nereide-zoom-continu.html').write_text(html)
print(f'Export autonome : {destination} ({destination.stat().st_size:,} octets)')
with zipfile.ZipFile(OUT / 'nereide-sources.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    sources = ['index.html', 'styles.css', 'build.py', 'README.md', 'package.json', '.gitignore', 'AGENTS.md', 'docs/ARCHITECTURE.md']
    sources += [str(path.relative_to(ROOT)) for folder in ('src', 'tests', 'docs/reference')
                for path in sorted((ROOT / folder).rglob('*'))
                if path.is_file() and path.suffix in ('.js', '.cjs', '.txt', '.pdf')]
    for relative in sources:
        path = ROOT / relative
        if path.exists():
            archive.write(path, 'nereide/' + relative)
print(f'Sources : {OUT / "nereide-sources.zip"}')
