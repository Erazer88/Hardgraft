(function (root) {
  'use strict';

  const Data = root.OrbitProcessData;
  const Graph = root.OrbitProcessGraph;
  const Simulation = root.OrbitProcessSimulation;
  const Stack = root.OrbitResourceStack;
  const Routing = root.OrbitDepotRouting;
  const Mix = root.OrbitComposition;

  function fraction(seed) {
    let hash = 2166136261;
    for (const letter of String(seed)) hash = Math.imul(hash ^ letter.charCodeAt(0), 16777619);
    return (hash >>> 0) / 4294967296;
  }

  function geology(state, building) {
    // Extractors drill rock, whatever it holds; an oil platform pumps oil and a
    // pumping station the water of its shore.
    if (!['extractor', 'oil_platform', 'water_station'].includes(building.type)) return null;
    const resourceId = building.type === 'extractor' ? 'rock' : building.resourceId;
    if (!resourceId) return null;
    const id = `${building.planetId}:${resourceId}:${building.x.toFixed(3)}:${building.y.toFixed(3)}`;
    return { id, planetId: building.planetId, resourceId,
      ...(building.type === 'extractor' && building.composition ? { composition: { ...building.composition } } : {}),
      hardness: Data.config.geology.hardnessRange[0] + fraction(state.seed + id) *
        (Data.config.geology.hardnessRange[1] - Data.config.geology.hardnessRange[0]),
      share: Number.isFinite(building.resourceShare) ? building.resourceShare : Data.config.geology.defaultShare };
  }

  function ensureGraph(state, building) {
    const ground = geology(state, building);
    const previous = state.factoryPlans[building.id];
    if (!previous || previous.version !== Data.config.version || !Array.isArray(previous.machines) ||
        (ground && previous.geology?.resourceId !== ground.resourceId)) {
      state.factoryPlans[building.id] = Graph.create({ version: Data.config.version,
        geology: ground });
    }
    const graph = state.factoryPlans[building.id];
    graph.geology ||= ground;
    for (const machine of graph.machines) {
      if (!Graph.definitionOf(machine).externalInput) continue;
      machine.outputBuffer.material ||= 0;
      if (!machine.importResourceId) {
        machine.importResourceId = Object.keys(building.inventory || {}).sort()
          .find(resourceId => Number.isInteger(building.inventory[resourceId]) && building.inventory[resourceId] > 0) || null;
      }
    }
    return graph;
  }

  function step(state, seconds) {
    const power = new Map(), demands = new Map();
    // Wind turbines at work, for their wakes.
    const turbines = state.surfaceBuildings.filter(building => building.type === 'wind_turbine' && building.constructionState === 'complete');
    for (const building of state.surfaceBuildings) {
      const complete = building.constructionState === 'complete';
      building.energyOutputUnlimited = complete && building.type === 'wind_turbine' && Data.config.windPowerUnlimited;
      if (!complete) continue;
      const entry = power.get(building.planetId) || { unlimited: false, megawatts: 0 };
      if (building.energyOutputUnlimited) entry.unlimited = true;
      if (building.type === 'wind_turbine') {
        // Its site and the turbines around it set what it gives.
        const Wind = root.OrbitWindPower;
        building.windWake = Wind ? Wind.wakeEfficiency(building, turbines) : 1;
        const megawatts = Wind ? Wind.outputMW(building, turbines) : Data.config.windPowerMW;
        building.energyOutputWatts = building.energyOutputUnlimited ? 0 : megawatts * 1e6;
        if (!building.energyOutputUnlimited) entry.megawatts += megawatts;
      }
      if (building.type === 'geothermal') {
        building.energyOutputWatts = Data.config.geothermalPowerMW * 1e6;
        entry.megawatts += Data.config.geothermalPowerMW;
      }
      // The colony's own generator.
      const generatorMW = root.OrbitBuildingData?.get(building.type)?.generatorMW || 0;
      if (generatorMW) {
        building.energyOutputWatts = generatorMW * 1e6;
        entry.megawatts += generatorMW;
      }
      power.set(building.planetId, entry);
      const savedGraph = state.factoryPlans[building.id];
      if (!savedGraph) continue;
      const graph = ensureGraph(state, building);
      // Incinerators burning waste feed the planet grid, from their smoothed rate.
      const generated = generatedMW(graph, seconds);
      building.energyOutputWatts = generated * 1e6;
      entry.megawatts += generated;
      const demand = isDepot(building) ? Routing.demand(graph) : Simulation.demand(graph, building.inventory) * energyFactor(building);
      demands.set(building.planetId, (demands.get(building.planetId) || 0) + demand);
    }

    // Supply and demand per planet, for the HUD and for unlocking turbines.
    state.powerStatus = Object.fromEntries([...new Set([...power.keys(), ...demands.keys()])].map(planetId => [planetId, {
      supplyMW: power.get(planetId)?.unlimited ? Infinity : power.get(planetId)?.megawatts || 0,
      demandMW: demands.get(planetId) || 0 }]));

    for (const building of state.surfaceBuildings) {
      if (building.constructionState !== 'complete' || !state.factoryPlans[building.id]) continue;
      const graph = ensureGraph(state, building);
      if (isDepot(building)) {
        // Its storage cards draw their power from the planet like any card.
        const available = power.get(building.planetId) || { unlimited: false, megawatts: 0 };
        const planetDemand = demands.get(building.planetId) || 0;
        const ratio = available.unlimited || planetDemand <= 1e-9 ? 1 : Math.min(1, available.megawatts / planetDemand);
        Routing.advance(graph, seconds, building, ratio);
        building.energyUse = graph.energyUsedMW * 1e6;
        building.flowPerMinute = graph.machines.reduce((sum, machine) =>
          Graph.definitionOf(machine).gate === 'output' ? sum + machine.currentRate * 60 : sum, 0);
        building.status = graph.machines.some(machine => machine.state === 'active') ? 'active' : 'waiting';
        continue;
      }
      const available = power.get(building.planetId) || { unlimited: false, megawatts: 0 };
      // A datacenter's cards draw their power times its cooling factor.
      const factor = energyFactor(building);
      const demand = Simulation.demand(graph, building.inventory) * factor, planetDemand = demands.get(building.planetId) || 0;
      Simulation.advance(graph, seconds, {
        energyUnlimited: available.unlimited,
        externalStock: building.inventory ||= {},
        externalMix: building.inventoryMix ||= {},
        // An output dock only works once its resource has a destination; a
        // datacenter's uplink once a high-frequency antenna is joined by road.
        isDockOpen: resourceId => building.type === 'datacenter'
          ? Boolean(root.OrbitDataNetwork?.uplinkAntenna(state, building)) : Boolean(building.dockDestinations?.[resourceId]),
        energyAvailableMW: planetDemand > 1e-9 ? available.megawatts * demand / planetDemand / factor : 0
      });
      building.energyUse = graph.energyUsedMW * factor * 1e6;
      building.flowPerMinute = graph.machines.reduce((sum, machine) => {
        return Graph.definitionOf(machine).externalOutput ? sum + machine.currentRate * 60 : sum;
      }, 0);
      building.dockFlowByResource = dockFlowByResource(building, graph);
      collectDockedResources(building, graph);
      building.status = graph.machines.some(machine => machine.state === 'active') ? 'active' : 'waiting';
    }
  }

  const isDepot = building => building.type === 'storage';
  // Power factor of a building's cards: a datacenter's grows with the heat of its site.
  const energyFactor = building => building.type === 'datacenter'
    ? root.OrbitDataNetworkData?.coolingFactor(building.siteTemperature) ?? 1 : 1;

  // Power from generators, each eased toward what its current burning rate
  // gives (machine.generatedMW, runtime only), so bursts and gaps in its
  // supply average out instead of switching the power on and off.
  function generatedMW(graph, seconds) {
    return graph.machines.reduce((sum, machine) => {
      const definition = Graph.definitionOf(machine);
      if (!definition?.generatesMW) return sum;
      // An instant generator gives power for what it really burned since the
      // last advance; another one for its current rate.
      let target = 0;
      if (definition.instant) {
        const burned = Math.max(0, (machine.movedTotal || 0) - (machine.burnedTotal ?? machine.movedTotal ?? 0));
        machine.burnedTotal = machine.movedTotal || 0;
        target = seconds > 0 ? burned / seconds * definition.generatedMWPerUnit : 0;
      } else if (machine.state === 'active') {
        target = definition.generatesMW * Math.min(1, (machine.currentRate || 0) / definition.throughput);
      }
      const smoothing = definition.generationSmoothingSeconds || 0;
      const blend = smoothing > 0 ? 1 - Math.exp(-seconds / smoothing) : 1;
      // The burning rate is smoothed as is (a burst counts in full), then the
      // power given is held to generatesMW.
      machine.burningMW = (machine.burningMW ?? machine.generatedMW ?? 0) + (target - (machine.burningMW ?? machine.generatedMW ?? 0)) * blend;
      if (machine.burningMW < 1e-3 && target === 0) machine.burningMW = 0;
      machine.generatedMW = Math.min(definition.generatesMW, machine.burningMW);
      return sum + machine.generatedMW;
    }, 0);
  }

  function collectDockedResources(building, graph) {
    building.dockStock ||= {};
    for (const machine of graph.machines) {
      const definition = Graph.definitionOf(machine);
      if (!definition.externalOutput) continue;
      const input = definition.inputPorts[0];
      const connection = graph.connections.find(item => item.toMachineId === machine.id && item.toInputId === input.id);
      const source = connection && graph.machines.find(item => item.id === connection.fromMachineId);
      const resource = source && Graph.definitionOf(source).outputPorts
        .find(port => port.id === connection.fromOutputId)?.resourceId;
      if (!resource) continue;
      // An uplink hands over only what its antenna can still take in
      // (uplinkMb); an output dock holds up to dockCapacity units waiting to
      // leave, then fills and stops the cards before it.
      const room = definition.dataUplink ? Math.max(0, (root.OrbitDataNetworkData?.datacenter.uplinkMb ?? Infinity) -
        Object.values(building.dockStock).reduce((sum, value) => sum + value, 0))
        : Math.max(0, Data.config.dockCapacity - (building.dockStock[resource] || 0));
      const amount = Math.min(machine.inputBuffer[input.id] || 0, room);
      if (!amount) continue;
      // Docked rock keeps its composition on the way out.
      building.dockMix ||= {};
      if (Mix) Mix.add(building.dockMix, resource, resource, building.dockStock[resource] || 0, amount, Mix.of(machine.inputMix, input.id));
      building.dockStock[resource] = (building.dockStock[resource] || 0) + amount;
      machine.inputBuffer[input.id] -= amount;
      // Units sent since the game started (runtime only), for the editor's rate.
      machine.movedTotal = (machine.movedTotal || 0) + amount;
      if (Mix) Mix.prune(machine.inputMix, input.id, machine.inputBuffer[input.id]);
    }
  }

  function dockFlowByResource(building, graph) {
    const rates = {};
    for (const machine of graph.machines) {
      const definition = Graph.definitionOf(machine);
      if (!definition.externalOutput) continue;
      const input = definition.inputPorts[0];
      const connection = graph.connections.find(item => item.toMachineId === machine.id && item.toInputId === input.id);
      const source = connection && graph.machines.find(item => item.id === connection.fromMachineId);
      const resource = source && Graph.definitionOf(source).outputPorts
        .find(port => port.id === connection.fromOutputId)?.resourceId;
      if (resource) rates[resource] = (rates[resource] || 0) + Math.max(0, machine.currentRate || 0);
    }
    return rates;
  }

  function advance(state, seconds) {
    if (!Number.isFinite(seconds) || seconds < 0) throw new RangeError('Industry duration must be finite and non-negative');
    state.industryAccumulator = (state.industryAccumulator || 0) + seconds;
    let count = 0;
    while (state.industryAccumulator + 1e-9 >= Data.config.fixedStepSeconds && count < Data.config.maxTicksPerAdvance) {
      step(state, Data.config.fixedStepSeconds);
      state.industryAccumulator = Math.max(0, state.industryAccumulator - Data.config.fixedStepSeconds);
      count++;
    }
  }

  function reclaimBuilding(state, building) {
    const graph = state.factoryPlans[building.id];
    state.colonyMaterials ||= [];
    if (graph) {
      const resolved = ensureGraph(state, building);
      for (const machine of resolved.machines) {
        const def = Graph.definitionOf(machine);
        for (const input of def.inputPorts) {
          const amount = machine.inputBuffer[input.id];
          const connection = graph.connections.find(item => item.toMachineId === machine.id && item.toInputId === input.id);
          const source = connection && resolved.machines.find(item => item.id === connection.fromMachineId);
          const resourceId = input.resourceId || (source && Graph.definitionOf(source).outputPorts
            .find(port => port.id === connection.fromOutputId)?.resourceId);
          if (amount && resourceId) Stack.addToStock(state.colonyMaterials, Stack.create({ resourceId,
            amount, origin: { kind: 'building', id: building.id } }));
        }
        for (const output of def.outputPorts) {
          const amount = machine.outputBuffer[output.id];
          if (amount) Stack.addToStock(state.colonyMaterials, Stack.create({ resourceId: output.resourceId,
            amount, origin: { kind: 'building', id: building.id } }));
        }
        for (const [resourceId, amount] of Object.entries(machine.storedResources || {})) {
          if (amount) Stack.addToStock(state.colonyMaterials, Stack.create({ resourceId,
            amount, origin: { kind: 'building', id: building.id } }));
        }
      }
      delete state.factoryPlans[building.id];
    }
    for (const [resourceId, amount] of Object.entries(building.inventory || {})) {
      if (Number.isInteger(amount) && amount > 0) Stack.addToStock(state.colonyMaterials,
        Stack.create({ resourceId, amount, origin: { kind: 'building', id: building.id } }));
    }
    for (const [resourceId, amount] of Object.entries(building.dockStock || {})) {
      if (Number.isInteger(amount) && amount > 0) Stack.addToStock(state.colonyMaterials,
        Stack.create({ resourceId, amount, origin: { kind: 'building', id: building.id } }));
    }
    for (const queue of Object.values(building.gateStock || {})) for (const [resourceId, amount] of Object.entries(queue)) {
      if (Number.isInteger(amount) && amount > 0) Stack.addToStock(state.colonyMaterials,
        Stack.create({ resourceId, amount, origin: { kind: 'building', id: building.id } }));
    }
    for (const [resourceId, amount] of Object.entries(building.launchStock || {})) {
      if (Number.isInteger(amount) && amount > 0) Stack.addToStock(state.colonyMaterials,
        Stack.create({ resourceId, amount, origin: { kind: 'building', id: building.id } }));
    }
  }

  root.OrbitIndustry = Object.freeze({ ensureGraph, advance, reclaimBuilding, geology });
})(globalThis);
