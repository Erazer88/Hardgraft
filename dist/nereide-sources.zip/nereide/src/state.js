(function (root) {
  'use strict';

  function normalizedSeed(value) {
    const text = String(value).trim() || root.OrbitConfig.defaultSeed;
    return /^\d{1,9}$/.test(text) ? Number(text) : text.slice(0, 64);
  }

  function create() {
    return { seed: root.OrbitConfig.defaultSeed, simulation: root.OrbitSimulation.create(),
      inventory: root.OrbitInventory.create(root.OrbitResourceData.startingInventory),
      exploration: root.OrbitExploration.create(), level: 'galaxy', selected: null,
      system: null, planet: null, camera: { x: 0, y: 0, zoom: .1 }, target: { x: 0, y: 0, zoom: .1 },
      paused: false, reveal: false, tool: 'pan', context: null,
      tracking: null, focusPlanet: null, surfaceBuildings: [], roadNetworks: {}, placement: null,
      factoryPlans: {}, colonyMaterials: [], industryAccumulator: 0,
      // Context points produced by the colony, and what its needs unlocked.
      contextPoints: 0, unlocks: { steps: [], buildings: [], cards: [] },
      orbitalLogistics: root.OrbitOrbitalTransit.createState(),
      roadPreview: null, buildMenuOpen: false };
  }

  root.OrbitState = Object.freeze({ create, normalizedSeed });
})(globalThis);
