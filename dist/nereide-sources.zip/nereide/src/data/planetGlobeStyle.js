(function (root) {
  'use strict';

  root.OrbitPlanetGlobeStyle = Object.freeze({
    mesh: Object.freeze({ longitudeSegments: 640, latitudeSegments: 320 }),
    relief: Object.freeze({ scale: .050, visualChainScale: 1.35, exponent: 1.00, linearFraction: .16,
      compressionStart: .42, peakTailStart: .70, landQuantile: .985, minLandRange: 24, maxLandRange: 58 }),
    stylizedTerrain: Object.freeze({
      // Keep the expensive CPU classification field compact; the final
      // material/normal maps are still uploaded at 512px for smooth sampling.
      fieldWidth: 192, textureWidth: 512,
      heightLowPass: .018, macroLowPass: .075, localLowPass: .010, classLowPass: .05,
      hillQuantile: .50, mountainQuantile: .83, summitQuantile: .975,
      normalReliefScale: .18, residualNormalStrength: 1.05, localNormalStrength: .16,
      macroNormalStrength: .14, plainNormalStrength: .04,
      // Low-frequency spherical cells are deliberately large enough to read
      // at the normal mobile globe zoom, not just in close-up diagnostics.
      plainFacetScale: 13.5, plainFacetStrength: .88, plainWashStrength: .88,
      facetMapScale: 2,
      visualChains: Object.freeze({
        baseCount: 10, minimumMultiplier: 3, maximumMultiplier: 4, islandChainRatio: .22,
        segmentCount: Object.freeze([5, 8]), segmentLength: Object.freeze([.065, .12]),
        width: Object.freeze([.045, .074]), uplift: .13, ridgeUplift: .080
      }),
      rollingNormalStrength: .22, hillockNormalStrength: .36, smallMassifNormalStrength: .20, hillNormalStrength: .28,
      smallMassifStrength: 1, highlandMaterialMix: .55,
      mountainNormalStrength: .60, facetAngleDegrees: 5.5, facetJitter: .24, facetStrength: .42,
      rollingLightingContrast: 1.25, sphereLightCancellation: .17, mountainShadowFloor: .74,
      shadowStrength: .30, shadowReach: .085,
      lightDirection: Object.freeze({ x: -.55, y: .70, z: .42 }),
      shallowBandWidth: .62, sandBandWidth: .82, coastAaMinimum: .10,
      coastSmoothing: 1.4, coastFieldBlur: .90,
      forests: Object.freeze({ patchCount: 56, minimumMoisture: .40, maximumLatitude: .88,
        patchRadius: Object.freeze([.045, .12]), colorMix: .82 }),
      water: Object.freeze({ deep: '#06375F', mid: '#0A6090', shallow: '#258EA8' }),
      materials: Object.freeze({
        temperate: Object.freeze({ plain: '#6FA84B', wet: '#477F3D', dry: '#9B9A54',
          rolling: '#78944D', hill: '#648345', foothill: '#827D4E', highland: '#A59A73', mountain: '#A9774F',
          ridge: '#D6B083', crevice: '#56483A', snow: '#E7ECEE', ice: '#BCD5DF', sand: '#D9BF76',
          forest: '#2E6138', canopy: '#4F8145' }),
        frozen: Object.freeze({ plain: '#C4DDE6', wet: '#BED9E3', dry: '#C9E0E7',
          rolling: '#B9D4DE', hill: '#B0CCD6', foothill: '#AEC9D2', highland: '#B4CED7', mountain: '#A3C0CB',
          ridge: '#E3EEF2', crevice: '#819AA4', snow: '#EDF4F6', ice: '#D0E5EC', sand: '#D9E8EC' }),
        arid: Object.freeze({ plain: '#BE7747', wet: '#A76844', dry: '#CB935C',
          rolling: '#C1814D', hill: '#A96743', foothill: '#A26443', highland: '#BD8A5B', mountain: '#8D5037',
          ridge: '#DBA46A', crevice: '#61392C', snow: '#DDD9D0', ice: '#C5CED0', sand: '#CE9B66' }),
        volcanic: Object.freeze({ plain: '#4B3630', wet: '#44312D', dry: '#60453A',
          rolling: '#594039', hill: '#5D4035', foothill: '#68483B', highland: '#866957', mountain: '#79503D',
          ridge: '#A87550', crevice: '#291E1B', snow: '#B59B87', ice: '#79503D', sand: '#654536' })
      })
    }),
    water: Object.freeze({ shallow: '#38A8C4', mid: '#12699C', deep: '#073666',
      noiseAmplitude: .012, normalStrength: .012, specularStrength: .13, fresnelStrength: .08,
      specularPower: 48, fresnelPower: 3,
      coastDepthDistance: 9, bathymetryDepthScale: 34, bathymetryInfluence: .10 }),
    polarCaps: Object.freeze({ thresholdBase: 76, temperatureReference: 16,
      temperatureScale: .38, minimumThreshold: 48, maximumThreshold: 82,
      broadFrequency: 3.8, secondFrequency: 7, secondWeight: .42,
      coastFrequency: 9.2, broadDisplacementDegrees: 24,
      maximumBroadShiftDegrees: 5.2, coastDisplacementDegrees: 1.6,
      maximumCoastShiftDegrees: 1.2, edgeHalfWidthDegrees: 1.35,
      eligibilityMarginDegrees: 10, latitudeCoolingExponent: 1.55,
      latitudeCoolingDegrees: 38 }),
    terrainShading: Object.freeze({ midReliefStrength: .72, microDetailStrength: 0,
      mountainFacetMix: .50, mountainAoStrength: .18, ridgeAccentStrength: .19,
      facetGrid: Object.freeze({ x: 60, y: 30 }),
      controls: Object.freeze({
        macroLod: 4, macroStepTexels: 8,
        hillLod: 3, hillStepTexels: 6,
        facetLod: 3.5, facetStepTexels: 4, structureLod: 2,
        plainNormalStrength: .08, hillNormalMix: .35, slopeScale: 2.2,
        polarNormalBlendStartDegrees: 88, polarNormalBlendEndDegrees: 90,
        polarNormalBlendStrength: .72,
        plainSlopeLow: .10, plainSlopeHigh: .24,
        hillHeightLow: .42, hillHeightHigh: .66,
        mountainHeightLow: .28, mountainHeightHigh: .68,
        mountainSlopeLow: .12, mountainSlopeHigh: .30,
        mountainMaskLow: .05, mountainMaskHigh: .42,
        ruggednessLow: .16, ruggednessHigh: .52,
        summitHeightLow: .66, summitHeightHigh: .88,
        rockExposure: .52, ridgeMaterialMix: .11, valleyMaterialMix: .08,
        shadowStrength: .34, highlightStrength: .24, coastBandStrength: .30,
        waterDiffuseAmbient: .94, waterDiffuse: .07,
        lightDirection: Object.freeze({ x: -.42, y: .55, z: .78 })
      }),
      mountainMaterials: Object.freeze({
        temperate: Object.freeze({ rock: '#A67550', ridge: '#D5AF7C', crevice: '#554437' }),
        frozen: Object.freeze({ rock: '#95AAB1', ridge: '#E2ECEE', crevice: '#617379' }),
        arid: Object.freeze({ rock: '#C28758', ridge: '#E5B47E', crevice: '#75503E' }),
        volcanic: Object.freeze({ rock: '#7D5648', ridge: '#AA7257', crevice: '#362A28' }),
        default: Object.freeze({ rock: '#B88F62', ridge: '#DFC29A', crevice: '#6D5843' })
      }) }),
    atmosphere: Object.freeze({ shellScale: 1.018, haloScale: 1.055,
      haloAlpha: .14, rimAlpha: .84, haloPower: 2.0, rimPower: 3.0,
      innerRim: Object.freeze({ color: '#39D3EC', edgeStrength: .28, inwardStrength: .12,
        edgeFalloff: 78, inwardFalloff: 18 }),
      colors: Object.freeze({ tellurique: '#64C9E8', océanique: '#35D2F2',
        glacée: '#C4E9F5', aride: '#F0B76C', volcanique: '#FF6336',
        gazeuse: '#B5A991', default: '#73C8E0' }) }),
    camera: Object.freeze({ minZoom: .8, maxZoom: 2.03, initialZoom: 1,
      radiusRatio: .4, rotationSensitivity: .006, maxPitch: .72, transitionMs: 320 }),
    resources: Object.freeze({ iron: '#d4a76d', copper: '#c88462', silicon: '#91b5b9',
      carbon: '#a6ad83', oil: '#8f877a' }),
    graticule: Object.freeze({ color: '#d0dddc', opacity: .05, widthPx: .55,
      longitudeStepDegrees: 30, latitudeStepDegrees: 30, sampleStepDegrees: 6 }),
    icon: Object.freeze({ sizePx: 34, hitRadiusPx: 24 }),
    topography: Object.freeze({ contourInterval: 9, majorInterval: 36,
      // Regular elevation bands read as global shadow waves on the globe.
      contourOpacity: 0, majorOpacity: 0 })
  });
})(globalThis);
