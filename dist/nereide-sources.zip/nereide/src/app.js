(function () {
  'use strict';
  const World = globalThis.OrbitWorld, Config = globalThis.OrbitConfig;
  const Camera = globalThis.OrbitCamera, Simulation = globalThis.OrbitSimulation;
  const Exploration = globalThis.OrbitExploration, Save = globalThis.OrbitSave;
  const BuildingData = globalThis.OrbitBuildingData, BuildingModel = globalThis.OrbitSurfaceBuilding;
  const BuildingPlacement = globalThis.OrbitBuildingPlacement, Construction = globalThis.OrbitConstruction;
  const SurfaceStyle = globalThis.OrbitSurfaceStyle;
  const $ = id => document.getElementById(id);
  const canvas = $('universe');
  const renderer = globalThis.OrbitRenderer.create(canvas);
  const hud = globalThis.OrbitHUD.create(document);
  const clamp = (n, a, b) => Math.max(a, Math.min(b, n));
  const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y);
  const state = globalThis.OrbitState.create();
  let galaxy, home, terrainTexture, terrainData;
  let nextBuildingId = 1;
  let W = innerWidth, H = innerHeight, DPR = Math.min(devicePixelRatio || 1, 2), lastTime = 0;
  let lastHUD = 0, pointerMoved = false, menuStarted = false, pinch = null;
  const viewport = { width: W, height: H };
  const pointers = new Map();
  const contexts = new Map();

  function stored() { try { return Save.load(localStorage); } catch (_) { return null; } }
  function persist() { try { Save.save(localStorage, state, galaxy); } catch (_) { /* Storage is optional. */ } }
  const normalizedSeed = globalThis.OrbitState.normalizedSeed;
  function project(x, y, cam = state.camera) { return Camera.project({ x, y }, cam, viewport); }
  function unproject(x, y, cam = state.camera) { return Camera.unproject({ x, y }, cam, viewport); }
  const toast = hud.toast;
  // One camera, one galactic coordinate space, at every level of detail.
  function zoomLimits(anchor = state.camera) {
    let max = Config.camera.maxZoom;
    if (state.context) {
      const planet = (state.level === 'surface' && state.tracking?.planet) || state.context.model.planets.find(p =>
        p.kind !== 'gazeuse' && distance(planetWorldPosition(p), anchor) <= p.radius * state.context.frame.scale * 1.4);
      // Stop at useful terrain detail rather than magnifying the raster into an
      // empty flat colour. This cap follows the planet's embedded map scale.
      if (planet) max = Math.min(max, Config.terrain.maxLocalZoom * Config.terrain.height * Config.terrain.textureScale / 2 / (planet.radius * state.context.frame.scale));
    }
    return [Config.camera.minZoom, max];
  }
  function focusCamera(x, y, zoom, immediate = false) {
    const [min, max] = zoomLimits({ x, y });
    state.target = { x, y, zoom: clamp(zoom, min, max) };
    if (immediate) state.camera = { ...state.target };
  }
  function fitZoom(span) { return Math.min(W - 60, H - 215) / span; }
  function localCamera(frame, camera = state.camera) { return Camera.toLocal(frame, camera); }
  function worldCamera(frame, camera) { return Camera.toWorld(frame, camera); }
  function prepareSystem(star) {
    if (contexts.has(star.id)) return contexts.get(star.id);
    const model = World.createSystem(state.seed, star.id, galaxy);
    const neighborDistance = Math.min(...galaxy.systems.filter(s => s.id !== star.id).map(s => distance(s, star)));
    const scale = Math.max(.001, Math.min(.012, neighborDistance * .32 / model.extent));
    const context = { star, model, frame: { x: star.x, y: star.y, scale }, terrains: new Map() };
    contexts.set(star.id, context); return context;
  }
  function planetWorldPosition(planet, context = state.context) {
    return Camera.worldPoint(context.frame, World.planetPosition(planet, state.simulation.time));
  }
  function prepareTerrain(planet, context = state.context) {
    if (!context.terrains.has(planet.id)) {
      terrainData = World.createTerrain(planet.seed, Config.terrain.width, Config.terrain.height, planet);
      terrainTexture = renderer.createTerrainTexture(planet, terrainData);
      context.terrains.set(planet.id, { data: terrainData, texture: terrainTexture });
    }
    const record = context.terrains.get(planet.id);
    terrainData = record.data;
    return record;
  }
  function surfaceFrame(planet = state.planet, context = state.context) {
    const record = prepareTerrain(planet, context);
    return Camera.surfaceFrame(planetWorldPosition(planet, context), planet.radius * context.frame.scale, record.texture);
  }
  function cameraMoving() { return Camera.moving(state.camera, state.target); }
  function followPlanet(planet, context = state.context) {
    if (state.tracking?.planet.id === planet.id && state.tracking.context === context) return;
    state.tracking = { planet, context, position: planetWorldPosition(planet, context) };
  }
  function systemViewZoom(model) {
    return Math.min(W - 60, Math.max(80, H - 300)) / (model.extent * 2.35);
  }
  function systemCamera() {
    const zoom = systemViewZoom(state.context.model);
    return worldCamera(state.context.frame, { x: 0, y: -30 / zoom, zoom });
  }
  function homeCamera() {
    if (state.level === 'galaxy') return { x: home.x - 200, y: home.y - 160, zoom: Math.max(.09, fitZoom(1900)) };
    if (state.level === 'system') return systemCamera();
    return worldCamera(surfaceFrame(), { x: terrainData.width * Config.terrain.textureScale / 2, y: terrainData.height * Config.terrain.textureScale / 2,
      zoom: Math.max(W / (terrainData.width * Config.terrain.textureScale), H / (terrainData.height * Config.terrain.textureScale)) * 1.08 });
  }
  function resetCamera(immediate = false) { const cam = homeCamera(); focusCamera(cam.x, cam.y, cam.zoom, immediate); }


  function regenerate(seed, restoring = null) {
    state.seed = normalizedSeed(seed); galaxy = World.createGalaxy(state.seed);
    home = galaxy.systems.find(s => s.id === galaxy.homeId);
    state.simulation = Simulation.create(); state.exploration = Exploration.create(home);
    Save.restore(state, galaxy, restoring);
    state.level = 'galaxy'; state.system = null; state.planet = null; state.selected = null;
    state.context = null; state.tracking = null; state.focusPlanet = null;
    state.surfaceBuildings = [];
    state.placement = null; state.buildMenuOpen = false; nextBuildingId = 1;
    state.tool = 'pan';
    terrainData = null; terrainTexture = null;
    contexts.clear();
    renderer.prepareGalaxy(galaxy, state.seed);
    focusCamera(home.x * .25, home.y * .3, Math.max(.045, fitZoom(6600)), true);
    $('seed-input').value = state.seed;
    $('inspector').hidden = true; updateUI(); persist();
  }

  function updateSceneContext() {
    if (!galaxy) return;
    const previousLevel = state.level, previousContext = state.context;
    const known = galaxy.systems.filter(s => s.discovered || state.reveal);
    if (state.tracking) state.context = state.tracking.context;
    if (state.camera.zoom >= .7 && !state.tracking && !cameraMoving()) {
      const nearest = [...known].sort((a, b) => distance(a, state.camera) - distance(b, state.camera))[0];
      const contextDistance = state.context ? distance(state.context.star, state.camera) : Infinity;
      const extent = state.context ? state.context.model.extent * state.context.frame.scale : 0;
      if (nearest && (!state.context || contextDistance > extent * 2 + Math.max(W, H) / state.camera.zoom * .7)) state.context = prepareSystem(nearest);
    }
    if (previousContext !== state.context) { state.focusPlanet = null; clearSelection(); }
    state.level = 'galaxy';
    if (state.context) {
      const context = state.context, frame = context.frame;
      const localZoom = state.camera.zoom * frame.scale;
      const center = project(frame.x, frame.y), visibleRadius = context.model.extent * localZoom;
      if (localZoom >= Math.min(.08, systemViewZoom(context.model) * .85) && center.x + visibleRadius >= 0 && center.x - visibleRadius <= W && center.y + visibleRadius >= 0 && center.y - visibleRadius <= H) {
        state.level = 'system'; state.system = context.model; state.exploration.visited.add(context.star.id);
        const selectedPlanet = state.selected?.kind ? state.selected : null;
        const candidates = context.model.planets.filter(p => p.kind !== 'gazeuse');
        const nearest = [...candidates].sort((a, b) => distance(planetWorldPosition(a, context), state.camera) - distance(planetWorldPosition(b, context), state.camera))[0];
        let planet = state.tracking?.planet || selectedPlanet || state.focusPlanet || nearest;
        if (planet && !context.model.planets.some(p => p.id === planet.id)) planet = nearest;
        const isVisible = p => {
          const position = planetWorldPosition(p, context), point = project(position.x, position.y), r = p.radius * localZoom;
          return point.x + r * 1.4 >= 0 && point.x - r * 1.4 <= W && point.y + r >= 0 && point.y - r <= H;
        };
        if (nearest && planet && !isVisible(planet) && isVisible(nearest)) planet = nearest;
        if (planet && planet.kind !== 'gazeuse') {
          const pp = planetWorldPosition(planet, context), point = project(pp.x, pp.y), r = planet.radius * localZoom;
          const visible = point.x + r * 1.4 >= 0 && point.x - r * 1.4 <= W && point.y + r >= 0 && point.y - r <= H;
          if (visible && r > 18) {
            state.focusPlanet = planet; prepareTerrain(planet, context);
            if (r > 45) followPlanet(planet, context);
            if (r >= 80) {
              state.level = 'surface'; state.planet = planet;
              const record = context.terrains.get(planet.id); terrainTexture = record.texture; terrainData = record.data;
            }
          }
        }
      }
    }
    if (state.tracking) {
      const r = state.tracking.planet.radius * state.tracking.context.frame.scale * state.camera.zoom;
      if (r < 22) state.tracking = null;
    }
    if (previousLevel !== state.level) {
      state.selected = null; state.tool = 'pan'; state.placement = null; state.buildMenuOpen = false;
      $('inspector').hidden = true; $('toast').classList.remove('visible'); updateUI();
    }
  }

  function renderUniverse(now) {
    const cam = state.camera;
    let visibleContexts = [];
    const closeSurface = state.level === 'surface' && state.planet &&
      state.planet.radius * state.context.frame.scale * cam.zoom > Math.max(W, H) * 1.5;
    if (cam.zoom >= .7 && !closeSurface) {
      const visibleStars = galaxy.systems.filter(s => s.discovered || state.reveal)
        .filter(s => { const p = project(s.x, s.y); const padding = 18 * cam.zoom; return p.x > -padding && p.x < W + padding && p.y > -padding && p.y < H + padding; })
        .sort((a, b) => distance(a, cam) - distance(b, cam)).slice(0, 12);
      if (state.context && !visibleStars.some(s => s.id === state.context.star.id)) visibleStars.push(state.context.star);
      visibleContexts = visibleStars.map(prepareSystem);
    }
    renderer.render({ state, galaxy, home, contexts, visibleContexts, now });
  }

  function clearSelection() {
    state.selected = null; state.tool = 'pan'; state.placement = null; state.buildMenuOpen = false;
    $('inspector').hidden = true; $('toast').classList.remove('visible');
  }
  function updateBuildingPreview(screenX, screenY, type = state.placement?.type) {
    if (state.level !== 'surface' || !state.planet || !terrainData || !terrainTexture) return;
    const definition = BuildingData.get(type);
    if (!definition) return;
    const frame = surfaceFrame(), worldPoint = unproject(screenX, screenY);
    const position = { x: (worldPoint.x - frame.x) / frame.scale, y: (worldPoint.y - frame.y) / frame.scale };
    const validation = BuildingPlacement.validate({ terrain: terrainData,
      textureScale: Config.terrain.textureScale, definition, position, planetId: state.planet.id,
      buildings: state.surfaceBuildings });
    state.placement = { type, ...position, rotation: 0, ...validation };
  }
  function placeSurfaceBuilding() {
    const preview = state.placement;
    if (!preview?.valid) {
      toast(preview?.reason || 'Choisissez un emplacement valide sur la planète.');
      return;
    }
    const definition = BuildingData.get(preview.type);
    const building = BuildingModel.create({ id: `${preview.type}-${state.planet.id}-${nextBuildingId++}`,
      type: preview.type, planetId: state.planet.id, x: preview.x, y: preview.y, rotation: preview.rotation,
      constructionState: 'constructing', constructionProgress: 0, status: 'building' });
    state.surfaceBuildings.push(building);
    state.placement = null; state.tool = 'pan'; state.buildMenuOpen = false;
    toast(`${definition.label} posé. Assemblage en cours.`); updateUI();
  }
  function chooseBuilding(type) {
    const definition = BuildingData.get(type);
    if (!definition || state.level !== 'surface') return;
    state.buildMenuOpen = false; state.tool = 'build'; state.selected = null;
    $('inspector').hidden = true;
    updateBuildingPreview(W / 2, H / 2, type);
    toast(`Déplacez l’aperçu de ${definition.label} et touchez pour le poser.`);
    updateUI();
  }
  function selectSurfaceBuilding(building) {
    state.tool = 'pan'; state.placement = null; state.buildMenuOpen = false;
    state.selected = { kind: 'building', ...building };
    hud.showSelection(state.selected, { state }); updateUI();
  }
  function buildingHit(frame, building, definition, x, y) {
    const anchor = project(frame.x + building.x * frame.scale, frame.y + building.y * frame.scale);
    const localZoom = state.camera.zoom * frame.scale;
    const footprintRadius = Math.max(definition.footprint.width, definition.footprint.height) * localZoom / 2 + 7;
    if (definition.id === 'factory') {
      const style = SurfaceStyle.buildings;
      const siteWidth = Math.max(style.siteImageMinWidthPx,
        definition.footprint.width * style.siteImageFootprintScale * localZoom);
      const siteHeight = siteWidth * 3 / 4;
      if (Math.abs(anchor.x - x) <= siteWidth / 2 + 4 && Math.abs(anchor.y - y) <= siteHeight / 2 + 4) return true;
    }
    if (Math.hypot(anchor.x - x, anchor.y - y) <= Math.max(18, footprintRadius)) return true;
    if (building.constructionState === 'complete') return false;

    const style = SurfaceStyle.buildings;
    const width = Math.max(style.cardMinWidthPx, Math.min(style.cardWidthPx, style.cardMaxWidthPx));
    const edge = definition.footprint.width * localZoom / 2 + 12;
    let cardX = anchor.x + edge, cardY = anchor.y - style.cardHeightPx / 2;
    if (cardX + width > W - 8) cardX = anchor.x - edge - width;
    cardX = Math.max(8, Math.min(W - width - 8, cardX));
    cardY = Math.max(8, Math.min(H - style.cardHeightPx - 8, cardY));
    return x >= cardX && x <= cardX + width && y >= cardY && y <= cardY + style.cardHeightPx;
  }
  function enterSystem() {
    if (state.level !== 'galaxy') return;
    const star = state.selected || home;
    if (!star.discovered && !state.reveal) return;
    state.context = prepareSystem(star); state.system = state.context.model;
    state.tracking = null; state.focusPlanet = null; clearSelection();
    const camera = systemCamera();
    focusCamera(camera.x, camera.y, camera.zoom); persist();
  }
  function enterPlanet() {
    if (state.level !== 'system') return;
    const planet = state.selected?.kind ? state.selected : state.system.planets.find(p => p.kind !== 'gazeuse');
    if (!planet) { toast('Aucun monde à surface solide dans ce système.'); return; }
    if (planet.kind === 'gazeuse') { toast('Cette géante gazeuse ne possède pas de surface solide.'); return; }
    const record = prepareTerrain(planet); state.focusPlanet = planet; state.planet = planet; followPlanet(planet);
    clearSelection();
    const f = surfaceFrame(planet), camera = worldCamera(f, { x: record.texture.width / 2, y: record.texture.height / 2, zoom: Math.max(W / record.texture.width, H / record.texture.height) * 1.08 });
    focusCamera(camera.x, camera.y, camera.zoom);
  }
  function back() {
    if (state.level === 'surface') {
      clearSelection(); state.tracking = null; state.focusPlanet = null;
      const camera = systemCamera();
      focusCamera(camera.x, camera.y, camera.zoom);
    } else if (state.level === 'system') {
      clearSelection(); state.tracking = null;
      const star = state.context.star; state.focusPlanet = null;
      focusCamera(star.x - 200, star.y - 160, Math.max(.09, fitZoom(1900)));
    } else { clearSelection(); state.tracking = null; overview(); }
  }
  function overview() {
    clearSelection(); state.tracking = null;
    if (state.level === 'galaxy') focusCamera(0, 0, fitZoom(11200));
    else if (state.level === 'system') {
      const camera = systemCamera();
      focusCamera(camera.x, camera.y, camera.zoom);
    } else {
      followPlanet(state.planet);
      const frame = surfaceFrame(), camera = worldCamera(frame, { x: terrainTexture.width / 2, y: terrainTexture.height / 2,
        zoom: Math.min((W - 30) / terrainTexture.width, (H - 200) / terrainTexture.height) });
      focusCamera(camera.x, camera.y, camera.zoom);
    }
  }
  function focusHome() {
    if (state.level === 'galaxy') { state.context = prepareSystem(home); state.tracking = null; select(home); resetCamera(); }
    else if (state.level === 'system') { state.tracking = null; state.focusPlanet = null; resetCamera(); }
    else { followPlanet(state.planet); resetCamera(); }
  }

  function select(item) {
    state.selected = item;
    if (state.level === 'system') state.focusPlanet = item;
    const systemModel = state.level === 'galaxy' ? prepareSystem(item).model : state.system;
    hud.showSelection(item, { state, systemModel }); updateUI();
  }
  function scanAt(point) {
    const from = state.selected && !state.selected.surfacePoint ? state.selected : home;
    Exploration.launch(state.exploration, from, point, performance.now());
    toast('Sonde en route. Relevé du secteur en cours.'); state.tool = 'pan'; updateUI();
  }
  function completeMissions(now) {
    for (const result of Exploration.advance(state.exploration, galaxy, now)) {
      const count = result.discoveredCount;
      toast(count ? `${count} systèmes détectés. Secteur cartographié.` : 'Secteur cartographié. Aucun nouveau système détecté.');
      persist(); updateUI();
    }
  }
  function updateUI() {
    const scaleCamera = state.level === 'galaxy' ? state.camera : state.level === 'system' ? localCamera(state.context.frame) : localCamera(surfaceFrame());
    hud.update({ state, galaxy, terrainData, width: W, scaleCamera });
  }

  function clickMap(x, y, doubleClick = false) {
    if ($('menu-dialog').open) return;
    const point = unproject(x, y);
    if (state.level === 'galaxy') {
      if (state.tool === 'scan') { scanAt(point); return; }
      const candidates = galaxy.systems.filter(s => s.discovered || state.reveal);
      let best = null, bestDistance = 18;
      for (const star of candidates) { const p = project(star.x, star.y), d = Math.hypot(p.x - x, p.y - y); if (d < bestDistance) { best = star; bestDistance = d; } }
      if (best) { select(best); if (doubleClick) enterSystem(); }
      else { $('inspector').hidden = true; state.selected = null; }
    } else if (state.level === 'system') {
      let best = null, bestDistance = 24;
      for (const planet of state.system.planets) {
        const pos = planetWorldPosition(planet), p = project(pos.x, pos.y), d = Math.hypot(p.x - x, p.y - y);
        if (d < bestDistance) { best = planet; bestDistance = d; }
      }
      if (best) { select(best); if (doubleClick) enterPlanet(); }
      else { $('inspector').hidden = true; state.selected = null; }
    } else {
      if (state.buildMenuOpen) { state.buildMenuOpen = false; updateUI(); }
      const frame = surfaceFrame(), terrainPoint = { x: (point.x - frame.x) / frame.scale, y: (point.y - frame.y) / frame.scale };
      if (state.tool === 'build') {
        updateBuildingPreview(x, y); placeSurfaceBuilding(); return;
      }
      const tx = Math.floor(terrainPoint.x / Config.terrain.textureScale), ty = Math.floor(terrainPoint.y / Config.terrain.textureScale);
      if (tx < 0 || ty < 0 || tx >= terrainData.width || ty >= terrainData.height) return;
      const building = [...state.surfaceBuildings].reverse().find(candidate => {
        if (candidate.planetId !== state.planet.id) return false;
        const definition = BuildingData.get(candidate.type);
        if (!definition) return false;
        return buildingHit(frame, candidate, definition, x, y);
      });
      if (building) { selectSurfaceBuilding(building); return; }
      const height = terrainData.elevation[ty * terrainData.width + tx], altitude = Math.round((height - terrainData.seaLevel) * 35);
      const names = height < 100 ? 'Zone océanique' : height < 109 ? 'Littoral' : height < 143 ? 'Plaine continentale' : height < 183 ? 'Plateau rocheux' : 'Massif montagneux';
      const nearest = terrainData.resources.find(resource => Math.hypot(resource.x - tx, resource.y - ty) < 10);
      select({ surfacePoint: true, x: terrainPoint.x, y: terrainPoint.y, altitude, name: names,
        info: nearest ? `Gisement détecté : ${nearest.type}. Les courbes de niveau indiquent la pente du terrain.` : 'Le relief, les côtes et les ressources composent une surface générée pour ce monde.' });
    }
  }
  function zoomAt(factor, x = W / 2, y = H / 2) {
    const before = unproject(x, y), [min, max] = zoomLimits(before);
    const z = clamp(state.camera.zoom * factor, min, max);
    state.target = Camera.anchoredZoom(state.camera, viewport, z, { x, y });
    state.camera = { ...state.target };
    updateSceneContext(); updateUI();
  }
  let lastTap = { t: 0, x: 0, y: 0 };
  canvas.addEventListener('pointerdown', e => {
    if ($('menu-dialog').open) return;
    canvas.setPointerCapture(e.pointerId);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    pointerMoved = false;
    if (state.tool === 'build' && pointers.size === 1) updateBuildingPreview(e.clientX, e.clientY);
    if (pointers.size === 2) {
      const points = [...pointers.values()];
      pinch = { distance: distance(points[0], points[1]), midpoint: { x: (points[0].x + points[1].x) / 2, y: (points[0].y + points[1].y) / 2 } };
      pointerMoved = true;
    }
  });
  canvas.addEventListener('pointermove', e => {
    if (!pointers.has(e.pointerId)) {
      if (state.tool === 'build') updateBuildingPreview(e.clientX, e.clientY);
      return;
    }
    const previous = pointers.get(e.pointerId);
    pointers.set(e.pointerId, { x: e.clientX, y: e.clientY });
    if (pointers.size >= 2 && pinch) {
      const points = [...pointers.values()], nextDistance = distance(points[0], points[1]);
      const midpoint = { x: (points[0].x + points[1].x) / 2, y: (points[0].y + points[1].y) / 2 };
      const before = unproject(pinch.midpoint.x, pinch.midpoint.y), [min, max] = zoomLimits(before);
      const zoom = clamp(state.camera.zoom * nextDistance / Math.max(1, pinch.distance), min, max);
      state.target = Camera.anchoredZoom(state.camera, viewport, zoom, midpoint, pinch.midpoint);
      state.camera = { ...state.target }; pinch = { distance: nextDistance, midpoint }; pointerMoved = true;
      updateSceneContext(); updateUI();
    } else if (pointers.size === 1 && state.tool === 'build') {
      if (Math.hypot(e.clientX - previous.x, e.clientY - previous.y) > 5) pointerMoved = true;
      updateBuildingPreview(e.clientX, e.clientY);
    } else if (pointers.size === 1) {
      if (Math.hypot(e.clientX - previous.x, e.clientY - previous.y) > 5) pointerMoved = true;
      if (pointerMoved) {
        state.target = { ...state.camera, x: state.camera.x - (e.clientX - previous.x) / state.camera.zoom,
          y: state.camera.y - (e.clientY - previous.y) / state.camera.zoom };
        state.camera = { ...state.target }; updateSceneContext();
      }
    }
  });
  function release(e, cancelled = false) {
    if (!pointers.has(e.pointerId)) return;
    const wasPinch = pinch !== null;
    pointers.delete(e.pointerId);
    if (pointers.size < 2) pinch = null;
    if (!cancelled && !pointerMoved && !wasPinch) {
      const now = performance.now(), double = now - lastTap.t < 340 && Math.hypot(lastTap.x - e.clientX, lastTap.y - e.clientY) < 24;
      clickMap(e.clientX, e.clientY, double); lastTap = { t: now, x: e.clientX, y: e.clientY };
    }
    if (wasPinch) pointerMoved = true;
  }
  canvas.addEventListener('pointerup', e => release(e));
  canvas.addEventListener('pointercancel', e => release(e, true));
  canvas.addEventListener('wheel', e => { e.preventDefault(); zoomAt(Math.exp(-e.deltaY * .0015), e.clientX, e.clientY); }, { passive: false });
  canvas.addEventListener('contextmenu', e => e.preventDefault());
  $('zoom-in').onclick = () => zoomAt(1.55); $('zoom-out').onclick = () => zoomAt(1 / 1.55);
  $('back-button').onclick = back; $('overview-button').onclick = overview; $('home-button').onclick = focusHome;
  $('pan-button').onclick = () => { state.tool = 'pan'; state.placement = null; state.buildMenuOpen = false; updateUI(); };
  $('build-button').onclick = () => {
    if (state.level !== 'surface') return;
    if (state.tool === 'build') { state.tool = 'pan'; state.placement = null; }
    else state.buildMenuOpen = !state.buildMenuOpen;
    if (state.buildMenuOpen) { state.tool = 'pan'; state.placement = null; state.selected = null; $('inspector').hidden = true; }
    updateUI();
  };
  $('build-menu-close').onclick = () => { state.buildMenuOpen = false; updateUI(); };
  $('build-options').addEventListener('click', event => {
    const option = event.target.closest('[data-building-type]');
    if (option) chooseBuilding(option.dataset.buildingType);
  });
  $('scan-button').onclick = () => { state.tool = state.tool === 'scan' ? 'pan' : 'scan'; state.buildMenuOpen = false; $('inspector').hidden = true; updateUI(); if (state.tool === 'scan') toast('Touchez la carte pour envoyer une sonde.'); };
  $('close-inspector').onclick = () => { state.selected = null; $('inspector').hidden = true; updateUI(); };
  $('enter-button').onclick = () => {
    if (state.level === 'galaxy') enterSystem();
    else if (state.level === 'system') enterPlanet();
  };
  $('breadcrumb-galaxy').onclick = () => {
    if (state.level === 'galaxy') { overview(); return; }
    const star = state.context.star; state.tracking = null; state.focusPlanet = null; clearSelection();
    focusCamera(star.x - 200, star.y - 160, Math.max(.09, fitZoom(1900)));
  };
  $('breadcrumb-system').onclick = () => { if (state.level === 'surface') back(); };
  $('menu-button').onclick = () => { state.buildMenuOpen = false; updateUI(); $('continue-button').firstElementChild.textContent = 'Reprendre l’exploration'; $('menu-dialog').showModal(); };
  $('continue-button').onclick = () => { $('menu-dialog').close(); if (!menuStarted) { menuStarted = true; toast('Zoomez sur Néréide pour explorer son système.'); } };
  $('reset-system-button').onclick = () => {
    regenerate(state.seed);
    $('continue-button').firstElementChild.textContent = 'Explorer cet univers';
    $('menu-dialog').close();
    toast(`Système réinitialisé avec la graine ${state.seed}.`);
  };
  $('generate-button').onclick = () => { regenerate($('seed-input').value); $('continue-button').firstElementChild.textContent = 'Explorer cet univers'; };
  $('seed-input').addEventListener('keydown', e => { if (e.key === 'Enter') $('generate-button').click(); });
  $('reveal-toggle').onchange = e => { state.reveal = e.target.checked; updateUI(); };
  function setPause(value) {
    state.paused = value; $('motion-toggle').checked = !value;
    $('pause-button').innerHTML = value ? '<svg viewBox="0 0 24 24"><path d="m8 5 11 7-11 7Z"/></svg>' : '<svg viewBox="0 0 24 24"><path d="M8 5v14M16 5v14"/></svg>';
    $('pause-button').setAttribute('aria-label', value ? 'Animer les orbites' : 'Mettre les orbites en pause'); updateUI();
  }
  $('pause-button').onclick = () => setPause(!state.paused); $('motion-toggle').onchange = e => setPause(!e.target.checked);
  document.addEventListener('keydown', e => {
    if (e.target instanceof HTMLInputElement) return;
    if (e.key === 'Escape') {
      if ($('menu-dialog').open) $('menu-dialog').close();
      else if (state.buildMenuOpen) { state.buildMenuOpen = false; updateUI(); }
      else if (state.tool !== 'pan') { state.tool = 'pan'; state.placement = null; updateUI(); }
      else if (!$('inspector').hidden) { $('inspector').hidden = true; state.selected = null; updateUI(); }
      else back();
    }
    if (e.key === '+' || e.key === '=') zoomAt(1.4);
    if (e.key === '-') zoomAt(1 / 1.4);
    if (e.key === ' ' && !$('menu-dialog').open) { e.preventDefault(); setPause(!state.paused); }
    if (e.key === 'Enter' && state.selected && !$('menu-dialog').open && !$('enter-button').hidden) $('enter-button').click();
    if (!$('menu-dialog').open && ['ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown'].includes(e.key)) {
      e.preventDefault(); const step = 70 / state.target.zoom;
      state.target.x += e.key === 'ArrowLeft' ? -step : e.key === 'ArrowRight' ? step : 0;
      state.target.y += e.key === 'ArrowUp' ? -step : e.key === 'ArrowDown' ? step : 0;
    }
  });
  function resize() {
    W = innerWidth; H = innerHeight; DPR = Math.min(devicePixelRatio || 1, 2);
    viewport.width = W; viewport.height = H; renderer.resize(W, H, DPR);
    if (galaxy) updateUI();
  }
  addEventListener('resize', resize); document.addEventListener('visibilitychange', () => { persist(); lastTime = 0; });

  function frame(now) {
    const dt = lastTime ? Math.min((now - lastTime) / 1000, Config.simulation.maxFrameSeconds) : 0; lastTime = now;
    Simulation.advance(state.simulation, dt, !state.paused && !document.hidden);
    if (!state.paused && !document.hidden) Construction.advance(state.surfaceBuildings, dt);
    if (state.tracking) {
      const follow = state.tracking, position = planetWorldPosition(follow.planet, follow.context);
      const dx = position.x - follow.position.x, dy = position.y - follow.position.y;
      state.camera.x += dx; state.camera.y += dy; state.target.x += dx; state.target.y += dy;
      follow.position = position;
    }
    completeMissions(now);
    state.camera = Camera.smooth(state.camera, state.target, dt, Config.camera.easingRate);
    updateSceneContext(); renderUniverse(now);
    if (now - lastHUD > 350) { updateUI(); lastHUD = now; }
    requestAnimationFrame(frame);
  }

  // A small inspection API supports browser checks without bypassing production paths.
  globalThis.OrbitalDebug = Object.freeze({
    getState: () => ({ level: state.level, seed: state.seed, selectedId: state.selected?.id || null,
      systemCount: galaxy.systems.length, discoveredCount: galaxy.systems.filter(s => s.discovered || state.reveal).length,
      planetCount: state.system?.planets.length || 0, zoom: state.camera.zoom, time: state.simulation.time,
      homeId: home.id, transitioning: false, moving: cameraMoving(), tool: state.tool,
      planetKind: state.planet?.kind || null, missions: state.exploration.missions.length }),
    focusHome, enterSystem, enterPlanet, back, regenerate, zoomAt,
    getCamera: () => ({ ...state.camera }),
    getHomeScreenPosition: () => project(home.x, home.y),
    getPlanetScreenPositions: () => (state.system?.planets || []).map(p => { const pos = planetWorldPosition(p); return { ...project(pos.x, pos.y), id: p.id, kind: p.kind }; }),
    scanAt, setPause
  });
  resize(); const previous = stored(); regenerate(previous?.seed ?? 'NEREIDE-01', previous);
  $('menu-dialog').showModal(); requestAnimationFrame(frame);
})();
