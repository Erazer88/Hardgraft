# Contexte courant

Résumé des décisions actives et des points d'entrée du prototype. Les détails d'un
système restent dans sa documentation spécialisée ; les anciens plans de
`docs/reference/` sont des archives et ne définissent pas l'implémentation actuelle.

## Architecture

- Prototype web sans framework. `index.html` charge des scripts IIFE exposés via
  `globalThis`; garder cet ordre et la compatibilité avec `build.py`.
- `src/data/` contient les réglages, `src/world/` la génération, `src/simulation/`
  les modèles, `src/gameplay/` leur raccordement, `src/ui/` les interactions,
  `src/rendering/` le dessin et `src/app.js` l'initialisation. Voir
  [`ARCHITECTURE.md`](ARCHITECTURE.md).
- La génération est déterministe par graine. Préserver navigation, sauvegardes et
  compatibilité mobile/desktop lors des changements.

## Décisions actives

### Monde et rendu

- Carte planétaire au style néon (Canvas 2D) : strates d'altitude teintées et ombrées
  comme du papier empilé, lignes d'altitude, rivières, lacs, marais, côtes lumineuses,
  grille de latitude. L'ancien rendu réaliste (biomes, textures, WebGL) et l'ancien
  système de maisons et quartiers décoratifs sont supprimés. Réglages :
  `src/data/surfaceStyle.js`.
- Continents et îles d'abord, puis `terrain.elevation` (hauteur canonique) et
  l'hydrologie. Lacs et criques sont de l'eau pour le gameplay ; les rivières ne
  bloquent rien. Voir [`WORLDGEN.md`](WORLDGEN.md).
- Plus de gisements : chaque zone du sol a sa composition (roche + fer, cuivre, silice,
  carbone ; pétrole en mer), en veines ramifiées. La carte de teneur sera plus tard
  révélée par un scan ; ratios et rendements restent à calibrer.
- Les bâtiments sont des balises hexagonales dont la taille suit le zoom (bornée), avec
  leur nom au-dessus. Noms par défaut « Usine 1 », « Usine 2 »… numérotés par type sur
  toute la galaxie, modifiables dans l'inspecteur ou le menu de la colonie. Les noms
  n'apparaissent qu'une fois les balises assez grandes (toujours pour la sélection),
  suivent un peu le zoom et ne se chevauchent jamais : un nom qui couvrirait un autre
  nom ou une balise passe sous sa balise, sinon il est omis (sélection, colonie et hub
  d'abord).

### Interface

- Vue principale épurée : barre du haut (population « HAB. », points « TECH » ou
  « CONTEXTE » en légende sous chaque chiffre, « Compétences » qui se réduit à son
  icône quand la place manque, menu ☰),
  barre d'actions en bas (retour nommé d'après l'échelle visée, « Route », « Construction »,
  « Sonde » en vue galaxie). Pause, plein écran et version sont dans le menu ; plus de
  boutons de zoom, d'échelle, de recentrage, de titres ni de graduations à l'écran
  (zoom au pincement, à la molette ou aux touches + et −).
- Fiche de bâtiment en panneau bas condensé : badge et nom, ligne niveau / énergie
  (consommée, ou produite en vert), des tuiles à icônes (vitesse et toutes les teneurs,
  débits de données…, valeurs sur plusieurs lignes), la provenance et les destinations
  des matières avec les noms des bâtiments (usine, dépôt, terril ; destinations des
  extracteurs et stations), les sources nommées d'une antenne relais, puis « Modifier »,
  « Enregistrer » et « Démolir ». Colonie et hub ont le même panneau : résumé, paliers
  ou matériaux à recevoir, flux, arrivées avec leurs expéditeurs. Plus de fil d'Ariane
  ni de libellé de lieu sur la carte. En vue planète, une jauge discrète
  « ⚡ consommation / production MW » sous la barre du haut (rouge en déficit).
- L'Arche et le relevé de terrain (clic sur le sol) ouvrent le même panneau bas : badge,
  tuiles (plateformes, arrivées, énergie, points tech ; altitude et rayon de forage),
  puis lignes d'arrivées et de stock, ou composition du sol en barres. Le menu du hub
  assemblé ne garde que les lancements.
- Menu Construction : filtres en puces (Tout, Production, Industrie, Énergie,
  Transport, Données, Enregistrés), une carte par bâtiment (badge et nom, motif
  d'indisponibilité) et un bouton « i » qui ouvre sa fiche de fonctionnement
  (`details`, emplacement, route, énergie, chantier) avec « Construire ». Plus de ligne
  de stock.
- Cartes de l'éditeur : état et débit sur une ligne, une large barre bleue (unité en
  cours, ou remplissage d'un quai), « ⚡ MW » de la carte et une note (stock d'un quai,
  teneur d'un séparateur). Liaisons courbes ou à angle droit (bouton de l'en-tête,
  choix gardé par le navigateur). Plus de symbole ∞.

- Performances en vue planète : sol (relief, minerais, côte, routes terminées) en
  cache réutilisé pendant les déplacements, balises, noms et halos en sprites, routes
  tracées en un chemin par passe. Détails et banc de mesure dans
  [`ARCHITECTURE.md`](ARCHITECTURE.md#performances-du-rendu-en-vue-planète).

### Colonie et progression

- La Colonie est le premier bâtiment, unique et indestructible, générateur 12 MW.
  Population 100 → 200 → 400 → 800 → 1 600 par paliers : 1 000 roches brutes, puis
  150 goudrons, puis 25 plaques, puis un hub assemblé. Dès le palier 2, les ressources
  des paliers précédents sont exigées en flux (roche 500/min, goudron 25/min, plaque
  1/min). Contexte : 1/min.
- À 800 habitants s'ouvrent le cuivre, le silicium, l'eau (station de pompage) et le
  hub, qui se bâtit avec des ressources livrées par route (plaques, goudron, cuivre,
  silicium, eau douce).
  Zone néon qui grandit avec ce qu'elle consomme ; on n'y construit pas.
- Les bâtiments et cartes apparaissent selon les besoins de la colonie ; le réglage
  développeur « Tout débloquer » montre tout.
- Un clic sur la colonie ouvre son menu (stats, flux en moyenne glissante sur 30 s,
  rafraîchi toutes les 5 s, unités u/ku/Mu…). Voir [`COLONY.md`](COLONY.md).

### Industrie

- Graphe de cartes par bâtiment, cycles et buffers entiers. Chaque carte appartient à
  son bâtiment : l'Extracteur fore (une seule Foreuse, 6 u/s), concasse et broie ;
  l'Usine sépare, réduit, fabrique goudron et plaques. Pour forer plus, poser plusieurs
  extracteurs côte à côte.
- La roche reste une seule ressource à chaque étape ; chaque stock garde une
  composition moyenne et les séparateurs tirent leur matériau selon la teneur
  (récupération 90 %).
- Docks, Quais, Portes de dépôt et trieurs logiques n'ont pas de limite de débit, mais
  un quai garde au plus 100 u par ressource (`dockCapacity`) : un bâtiment à cartes ne
  reçoit plus au-delà, un Dock de sortie plein arrête l'amont. Un Dock de sortie sans
  destination n'absorbe rien (« SANS DESTINATION ») et bloque l'amont.
- Les résidus d'un séparateur perdent exactement la part récupérée (lot × teneur ×
  90 %), même quand le crédit de rendement paie une unité entière : le métal est
  conservé (tests de teneurs de 0 à 80 % sur tous les séparateurs).
- Bâtiments spécialisés : Station de pompage, Dépôt répartiteur, Terril (retraitement
  ou incinération productrice d'énergie), Plateforme de lancement. Pas de pollution.
- Le gameplay est fonctionnel jusqu'à l'Arche. L'arbre de compétences s'ouvre aux
  premières ressources reçues par l'Arche : « Réveil des archives », « Réseau
  informatique » (Datacenter, Antenne relais, Antenne haute fréquence), « Atterrisseur »
  (colonie sur les autres mondes rocheux, laboratoires partout). Les données
  (géologiques, industrielles, planétaires) vont par une chaîne d'antennes relais au
  datacenter, ses analyses par l'antenne haute fréquence à l'Arche, où chacune devient
  un point de technologie (monnaie de l'arbre, à la place du Contexte). Débit stable,
  coupé par la conjonction solaire, 3× plus rapide que le fret. Voir
  [`SKILL_TREE.md`](SKILL_TREE.md) et [`DATA_NETWORK.md`](DATA_NETWORK.md).
- Une colonie par planète. Le fret vers l'Arche est 2× plus lent qu'avant
  (`cargoSpeedMultiplier: .35`).
- Bibliothèque du joueur hors sauvegarde : bâtiments enregistrés (menu Construction,
  filtre « Enregistrés ») et blueprints de cartes (éditeur, bouton « Blueprints »).
- Énergie limitée (colonie 12 MW, éolienne 32 MW, incinérateur lissé sur 20 s). Un
  bouton « PROBLÈMES » en haut à droite liste les alertes en cours : énergie
  insuffisante, dock sans destination, flux de colonie en retard ; une alerte reste 3 s
  après sa cause et sélectionne son bâtiment au toucher. Deux équipes de robots, 2 s de
  construction par bâtiment. Prix masqués (`pricesEnabled: false`).
  Voir [`PROCESS_SYSTEM.md`](PROCESS_SYSTEM.md).

### Routes et logistique

- Routes manuelles qui suivent le relief (vallées, lacets, ponts sur les rivières et
  sur les détroits étroits), affichées en filament néon. Voies maritimes entre ports
  et plateformes. Démolir un bâtiment retire ses routes propres.
- Le Dock envoie vers la Colonie, une usine ou un terril avec Quai d'entrée, un dépôt
  avec Porte d'entrée ou une Plateforme de lancement, si un chemin construit les relie
  (routes et voies maritimes via les ports). Transfert instantané, sans capacité de
  route ; des impulsions lumineuses purement informatives montrent les liaisons
  actives. Voir [`ROAD_SYSTEM.md`](ROAD_SYSTEM.md) et
  [`ORBITAL_LOGISTICS.md`](ORBITAL_LOGISTICS.md).

### Sauvegardes

- `saveVersion` 10 ; une sauvegarde plus ancienne démarre une nouvelle partie.

## Questions ouvertes

Proposées au joueur, non décidées — ne pas implémenter sans demande :

- passer les séparateurs gravitaire et de carbone à 6 u/s comme le magnétique ;
- flux exigés par la colonie après le dernier palier ;
- traitement des déchets par type (incinération réservée aux combustibles, laitier →
  ciment, résidus → granulats, saumure → sel, terril visible).

## Points d'entrée et vérification

| Sujet | Code de départ | Vérification ciblée |
| --- | --- | --- |
| Monde et graine | `src/world.js`, `src/data/worldgen.js` | `node --test src/world.test.cjs` |
| Caméra et navigation | `src/navigation/camera.js`, `src/app.js`, `src/state.js` | `node --test tests/architecture.test.cjs` |
| Processus industriels | `src/simulation/processGraph.js`, `src/simulation/processSimulation.js` | `node --test tests/process-simulation.test.cjs` |
| Colonie et déblocage | `src/simulation/colony.js`, `src/gameplay/progression.js`, `src/gameplay/colonyZone.js` | `node --test tests/orbital-logistics.test.cjs` |
| Routes | `src/simulation/roadNetwork.js`, `src/gameplay/roadPlacement.js` | `node --test tests/architecture.test.cjs` |
| Logistique | `src/simulation/logisticsNetwork.js`, `src/gameplay/logistics.js` | `node --test tests/orbital-logistics.test.cjs` |
| Sauvegardes | `src/storage/save.js`, `src/state.js` | `node --test tests/architecture.test.cjs` |
| Export autonome | `build.py`, `index.html` | `python3 build.py` |

Pour une livraison complète, `npm test` lance la suite ; les tests navigateur sont
nécessaires lorsque la navigation, les gestes ou l'interface changent.
